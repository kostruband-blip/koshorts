import json
import re
import sys
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import auto_update_directory as aud
CYRILLIC_RE = re.compile(r"[А-Яа-яЁёІіЇїЄєҐґ]")


class CreatorDirectoryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tools = json.loads((ROOT / "tools.json").read_text(encoding="utf-8"))

    def test_minimum_tools_and_categories_distribution(self) -> None:
        self.assertGreaterEqual(len(self.tools), 24)
        by_cat = {c: 0 for c in aud.VALID_CATEGORIES}
        for item in self.tools:
            self.assertIn(item["category"], by_cat)
            by_cat[item["category"]] += 1
        for cat, count in by_cat.items():
            self.assertGreaterEqual(count, 4, f"Category {cat} should have at least 4 tools")

    def test_flagship_koshorts_is_first_and_featured(self) -> None:
        first = self.tools[0]
        self.assertEqual(first["id"], "koshorts-ai-studio")
        self.assertEqual(first["name"], "KoShorts AI Studio")
        self.assertTrue(first["featured"])
        self.assertEqual(first["url"], "https://koshorts.vercel.app/")
        self.assertEqual(first["tg"], "https://t.me/remtex_shorts_ai_bot")

    def test_strict_schema_and_zero_cyrillic_in_english_fields(self) -> None:
        seen_ids = set()
        required_keys = {
            "id",
            "name",
            "category",
            "featured",
            "badge_en",
            "badge_ru",
            "pricing_type",
            "pricing_en",
            "pricing_ru",
            "desc_en",
            "desc_ru",
            "tags",
            "url",
            "tg",
            "added_at",
        }
        for item in self.tools:
            self.assertTrue(required_keys.issubset(item.keys()), f"Missing keys in {item.get('id')}")
            self.assertNotIn(item["id"], seen_ids)
            seen_ids.add(item["id"])
            self.assertIn(item["pricing_type"], aud.VALID_PRICING_TYPES)
            self.assertIsInstance(item["featured"], bool)
            self.assertGreaterEqual(len(item["tags"]), 3)
            self.assertLessEqual(len(item["tags"]), 5)
            for en_key in ("name", "badge_en", "pricing_en", "desc_en"):
                self.assertIsNone(
                    CYRILLIC_RE.search(item[en_key]),
                    f"Cyrillic found in {item['id']}.{en_key}: {item[en_key]}",
                )
            for tag in item["tags"]:
                self.assertIsNone(CYRILLIC_RE.search(tag), f"Cyrillic found in tag {tag}")
            self.assertIsNotNone(CYRILLIC_RE.search(item["desc_ru"]))

    def test_index_html_has_zero_cyrillic_by_default(self) -> None:
        html = (ROOT / "index.html").read_text(encoding="utf-8")
        self.assertIsNone(CYRILLIC_RE.search(html), "index.html default English markup must contain zero Cyrillic")
        self.assertIn("https://koshorts.vercel.app/", html)
        self.assertIn("https://t.me/remtex_shorts_ai_bot", html)
        self.assertIn("$19 (790 UAH)", html)
        self.assertIn("$49 (1990 UAH)", html)

    def test_deduplication_and_dead_url_filtering(self) -> None:
        mock_candidates = [
            # Duplicate of existing OpusClip domain -> must be skipped
            {
                "id": "opus-clip-dup",
                "name": "OpusClip Pro",
                "category": "shorts",
                "featured": True,
                "badge_en": "Clipper",
                "badge_ru": "Клиппер",
                "pricing_type": "freemium",
                "pricing_en": "Free tier",
                "pricing_ru": "Есть бесплатный план",
                "desc_en": "Duplicate domain test entry.",
                "desc_ru": "Тестовая дублирующая запись.",
                "tags": ["shorts", "ai", "video"],
                "url": "https://opus.pro/pricing",
                "tg": "",
                "added_at": "2026-11-25",
            },
            # Dead/hallucinated URL -> must be skipped
            {
                "id": "fake-dead-tool",
                "name": "FakeDeadTool",
                "category": "shorts",
                "featured": False,
                "badge_en": "New AI",
                "badge_ru": "Новинка",
                "pricing_type": "free",
                "pricing_en": "Free",
                "pricing_ru": "Бесплатно",
                "desc_en": "Tool with unreachable domain.",
                "desc_ru": "Инструмент с недоступным доменом.",
                "tags": ["shorts", "clips", "video"],
                "url": "https://dead-domain-404.example.com",
                "tg": "",
                "added_at": "2026-11-25",
            },
            # Valid brand-new tool -> must be accepted with featured forced False
            {
                "id": "autopod-ai",
                "name": "AutoPod",
                "category": "shorts",
                "featured": True,
                "badge_en": "Premiere Plugin",
                "badge_ru": "Плагин Premiere",
                "pricing_type": "paid",
                "pricing_en": "From $29/mo",
                "pricing_ru": "От $29/мес",
                "desc_en": "Automated multi-camera podcast editor and social clip creator for Adobe Premiere Pro.",
                "desc_ru": "Автоматический монтаж многокамерных подкастов и нарезка клипов прямо в Adobe Premiere Pro.",
                "tags": ["premiere pro", "podcast editing", "social clips"],
                "url": "https://www.autopod.fm",
                "tg": "",
                "added_at": "2026-11-25",
            },
        ]

        added = aud.expand_directory(
            count=2,
            target_category="shorts",
            dry_run=True,
            candidates_provider=lambda _prompt: mock_candidates,
            url_checker=lambda url: "dead-domain" not in url,
        )
        self.assertEqual(len(added), 1)
        self.assertEqual(added[0]["id"], "autopod-ai")
        self.assertFalse(added[0]["featured"])

    def test_gemini_key_and_model_rotation_on_429_and_503(self) -> None:
        calls = []

        class DummyResp:
            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

            def read(self):
                return json.dumps(
                    {"candidates": [{"content": {"parts": [{"text": '[{"id":"ok-tool"}]'}]}}]}
                ).encode("utf-8")

        def fake_urlopen(req, timeout=45):
            calls.append(req.full_url)
            if len(calls) == 1:
                raise urllib.error.HTTPError(req.full_url, 429, "Too Many Requests", {}, None)
            if len(calls) == 2:
                raise urllib.error.HTTPError(req.full_url, 503, "Service Unavailable", {}, None)
            return DummyResp()

        with patch("urllib.request.urlopen", side_effect=fake_urlopen), patch("time.sleep"):
            res = aud.query_gemini_with_rotation(
                "test prompt",
                api_keys=["key_one", "key_two"],
                models=("gemini-flash-latest", "gemini-3.8-flash"),
            )
        self.assertEqual(len(calls), 3)
        self.assertIn("gemini-flash-latest", calls[0])
        self.assertIn("key=key_one", calls[0])
        self.assertIn("gemini-flash-latest", calls[1])
        self.assertIn("key=key_two", calls[1])
        self.assertIn("gemini-3.8-flash", calls[2])
        self.assertEqual(res[0]["id"], "ok-tool")


if __name__ == "__main__":
    unittest.main()
