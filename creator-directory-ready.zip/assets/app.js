(function () {
  'use strict';

  var CATEGORIES = ['all', 'shorts', 'captions', 'dubbing', 'thumbnails', 'analytics', 'telegram'];

  var I18N = {
    en: {
      meta_title: 'CreatorDirectory — Best AI Tools & Telegram Bots for YouTube, TikTok & Reels Creators',
      meta_desc: 'Curated directory of 30+ verified AI tools and Telegram bots for video creators: Shorts clippers, dynamic captions, AI dubbing, high-CTR thumbnails, and channel analytics.',
      skip: 'Skip to directory',
      aria_home: 'CreatorDirectory home',
      aria_nav: 'Primary navigation',
      aria_lang: 'Language switcher',
      aria_search: 'Search AI tools by name, description, or tag',
      aria_clear: 'Clear search query',
      aria_price_filter: 'Filter by pricing model',
      aria_cat_filter: 'Filter by tool category',
      aria_sort: 'Sort tools',
      nav_dir: 'Directory',
      nav_submit: 'Submit Tool',
      nav_faq: 'FAQ',
      hdr_cta_long: '+ Submit Tool',
      hdr_cta_short: '+ Submit',
      hero_pill: 'Updated Weekly · Verified Creator Stack 2026',
      hero_h1_1: 'Best AI Tools & Telegram Bots for ',
      hero_h1_hl: 'Video Creators',
      hero_sub: 'Hand-picked tools for YouTube, TikTok, Instagram Reels, and Telegram channels. Turn long videos into viral Shorts, add kinetic captions, dub into 100+ languages, and grow faster.',
      stat_1_val: '30+',
      stat_1_lbl: 'verified tools',
      stat_2_val: '6',
      stat_2_lbl: 'creator categories',
      stat_3_val: '0',
      stat_3_lbl: 'dead or fake links',
      dir_heading: 'AI Tools and Telegram Bots Catalog',
      search_ph: 'Search tools, e.g. "youtube shorts", "telegram bot", "lip sync", "ctr"...',
      price_all: 'All',
      price_freemium: 'Free / Freemium',
      price_paid: 'Paid',
      cat_all: 'All Tools',
      cat_shorts: 'Shorts & Clipping',
      cat_captions: 'Captions & Subtitles',
      cat_dubbing: 'Voice & Dubbing',
      cat_thumbnails: 'Thumbnails & Art',
      cat_analytics: 'Analytics & SEO',
      cat_telegram: 'Telegram Bots',
      sort_label: 'Sort:',
      sort_featured: 'Featured First',
      sort_newest: 'Newest Added',
      sort_az: 'Name (A–Z)',
      ptype_free: 'Free',
      ptype_freemium: 'Freemium',
      ptype_paid: 'Paid',
      btn_website: 'Visit Website ↗',
      btn_telegram: 'Open in Telegram ↗',
      empty_title: 'No matching tools found',
      empty_desc: 'Try clearing your search query or switching pricing and category filters.',
      empty_reset: 'Reset All Filters',
      sub_eyebrow: 'For AI Founders & Bot Makers',
      sub_title: 'Submit Your Tool to CreatorDirectory',
      sub_desc: 'Get discovered by YouTube creators, Reels editors, and Telegram channel owners actively looking for workflow automation.',
      t1_name: 'Standard Listing',
      t1_price: 'Free',
      t1_period: 'Moderation queue up to 14 days',
      t1_f1: 'Permanent card in 1 relevant category',
      t1_f2: 'Searchable by name, description & tags',
      t1_f3: 'Manual URL & quality verification',
      t1_cta: 'Submit for Free',
      t2_name: 'Fast-Track Review',
      t2_price: '$19 (790 UAH)',
      t2_period: 'One-time · Published within 24 hours',
      t2_f1: 'Priority moderation & live listing in 24h',
      t2_f2: 'Verified badge on your tool card',
      t2_f3: 'Direct Website + Telegram Bot buttons',
      t2_f4: 'Bilingual EN + RU copy polish included',
      t2_cta: 'Get Fast-Track ($19)',
      t3_pill: 'MAX REACH · TOP CONVERSION',
      t3_name: 'Top-3 Featured Spot',
      t3_price: '$49 (1990 UAH)',
      t3_period: '30 days · Homepage & Category Top-3',
      t3_f1: 'Pinned in Top-3 on Homepage & Category for 30 days',
      t3_f2: 'Signature gold border & spotlight highlight',
      t3_f3: 'Custom promo badge + instant 24h launch',
      t3_f4: 'Announcement in our creator Telegram digest',
      t3_cta: 'Book Top-3 Spot ($49)',
      faq_eyebrow: 'Questions & Answers',
      faq_title: 'How CreatorDirectory Works',
      q1_t: 'How do you verify tools in the directory?',
      q1_a: 'Every tool and Telegram bot is checked for active HTTP availability, real creator utility, transparent pricing, and clean UX. Dead or parked domains are never listed.',
      q2_t: 'How often are new AI tools added?',
      q2_a: 'Our automated discovery pipeline + editorial review adds verified new AI tools and creator bots every Monday, keeping all 6 categories fresh.',
      q3_t: 'How do I submit my AI service or Telegram bot?',
      q3_a: 'Choose a listing tier above and click Submit to message our bot on Telegram. Send your product URL, short description, and preferred category.',
      foot_desc: 'Independent curated directory of AI tools and Telegram bots for YouTube, TikTok, Reels, and Telegram creators.',
      foot_powered_prefix: 'Powered by ',
      foot_powered_link: 'KoShorts AI Studio'
    },
    ru: {
      meta_title: 'CreatorDirectory — лучшие AI-инструменты и Telegram-боты для авторов YouTube, TikTok и Reels',
      meta_desc: 'Каталог 30+ проверенных нейросетей и Telegram-ботов для креаторов: нарезка Shorts, динамические субтитры, дубляж голоса, обложки YouTube и аналитика каналов.',
      skip: 'Перейти к каталогу',
      aria_home: 'CreatorDirectory — на главную',
      aria_nav: 'Основная навигация',
      aria_lang: 'Переключение языка',
      aria_search: 'Поиск сервисов по названию, описанию или тегам',
      aria_clear: 'Очистить строку поиска',
      aria_price_filter: 'Фильтр по модели оплаты',
      aria_cat_filter: 'Фильтр по категории',
      aria_sort: 'Сортировка каталога',
      nav_dir: 'Каталог',
      nav_submit: 'Добавить сервис',
      nav_faq: 'Вопросы',
      hdr_cta_long: '+ Добавить сервис',
      hdr_cta_short: '+ Добавить',
      hero_pill: 'Обновляется каждую неделю · Проверенный стек 2026',
      hero_h1_1: 'Лучшие AI-инструменты и Telegram-боты для ',
      hero_h1_hl: 'авторов контента',
      hero_sub: 'Отобранные сервисы для авторов YouTube, TikTok, Instagram Reels и Telegram-каналов: автонарезка длинных видео в Shorts, живые субтитры, дубляж на 100+ языков и рост охватов.',
      stat_1_val: '30+',
      stat_1_lbl: 'проверенных сервисов',
      stat_2_val: '6',
      stat_2_lbl: 'категорий для авторов',
      stat_3_val: '0',
      stat_3_lbl: 'битых или фейковых ссылок',
      dir_heading: 'Каталог AI-инструментов и Telegram-ботов',
      search_ph: 'Поиск по названию, задачам или тегам: shorts, субтитры, озвучка, обложки...',
      price_all: 'Все',
      price_freemium: 'Бесплатно / Freemium',
      price_paid: 'Платные',
      cat_all: 'Все сервисы',
      cat_shorts: 'Shorts и нарезка',
      cat_captions: 'Субтитры',
      cat_dubbing: 'Озвучка и дубляж',
      cat_thumbnails: 'Обложки и дизайн',
      cat_analytics: 'Аналитика и SEO',
      cat_telegram: 'Telegram-боты',
      sort_label: 'Сортировка:',
      sort_featured: 'Сначала рекомендуемые',
      sort_newest: 'Сначала новые',
      sort_az: 'По алфавиту (A–Z)',
      ptype_free: 'Бесплатно',
      ptype_freemium: 'Freemium',
      ptype_paid: 'Платный',
      btn_website: 'Открыть сайт ↗',
      btn_telegram: 'Открыть в Telegram ↗',
      empty_title: 'По вашему запросу ничего не найдено',
      empty_desc: 'Попробуйте очистить поиск или переключить фильтры категории и модели оплаты.',
      empty_reset: 'Сбросить все фильтры',
      sub_eyebrow: 'Для создателей AI-сервисов и ботов',
      sub_title: 'Добавить сервис в CreatorDirectory',
      sub_desc: 'Получите целевых пользователей среди авторов YouTube, монтажёров Reels и владельцев Telegram-каналов.',
      t1_name: 'Базовое размещение',
      t1_price: 'Бесплатно',
      t1_period: 'Очередь модерации до 14 дней',
      t1_f1: 'Вечная карточка сервиса в выбранной категории',
      t1_f2: 'Поиск по названию, описанию и ключевым тегам',
      t1_f3: 'Ручная проверка рабочей ссылки и качества',
      t1_cta: 'Отправить бесплатно',
      t2_name: 'Ускоренная публикация',
      t2_price: '$19 (790 грн)',
      t2_period: 'Разово · Публикация за 24 часа',
      t2_f1: 'Приоритетная модерация и выход в каталог за 24 часа',
      t2_f2: 'Отметка проверки на карточке вашего сервиса',
      t2_f3: 'Прямые кнопки на сайт и вашего Telegram-бота',
      t2_f4: 'Редактура описания на английском и русском языках',
      t2_cta: 'Ускорить за $19 (790 грн)',
      t3_pill: 'МАКСИМУМ ПЕРЕХОДОВ · ТОП-3',
      t3_name: 'Закрепление в ТОП-3',
      t3_price: '$49 (1990 грн)',
      t3_period: 'На 30 дней · Вверху главной и категории',
      t3_f1: 'Закрепление вверху главной страницы и категории на 30 дней',
      t3_f2: 'Выделение золотой рамкой и бейджем рекомендаций',
      t3_f3: 'Приоритетная публикация за 24 часа без очереди',
      t3_f4: 'Упоминание сервиса в еженедельной сводке новинок',
      t3_cta: 'Занять ТОП-3 за $49 (1990 грн)',
      faq_eyebrow: 'Частые вопросы',
      faq_title: 'Как устроен каталог CreatorDirectory',
      q1_t: 'Как проверяются сервисы перед публикацией?',
      q1_a: 'Каждый сервис и Telegram-бот проходит автоматическую проверку доступности ссылки, наличия понятных тарифов и реальной пользы для видеокреаторов.',
      q2_t: 'Как часто каталог пополняется новинками?',
      q2_a: 'Каждый понедельник система автопоиска и модерации добавляет свежие проверенные AI-инструменты и ботов во все 6 категорий.',
      q3_t: 'Как подать заявку на размещение своего продукта?',
      q3_a: 'Выберите подходящий тариф выше и нажмите кнопку заявки — откроется наш бот в Telegram, куда достаточно прислать ссылку и краткое описание сервиса.',
      foot_desc: 'Независимый каталог лучших AI-инструментов и Telegram-ботов для авторов YouTube, TikTok, Reels и Telegram-каналов.',
      foot_powered_prefix: 'Работает на базе ',
      foot_powered_link: 'KoShorts AI Studio'
    }
  };

  var state = {
    lang: 'en',
    category: 'all',
    pricing: 'all',
    query: '',
    sort: 'featured',
    tools: []
  };

  var root = document.documentElement;
  var metaDesc = document.querySelector('meta[name="description"]');
  var ogTitle = document.querySelector('meta[property="og:title"]');
  var ogDesc = document.querySelector('meta[property="og:description"]');
  var twTitle = document.querySelector('meta[name="twitter:title"]');
  var twDesc = document.querySelector('meta[name="twitter:description"]');

  var searchInput = document.getElementById('search-input');
  var searchClear = document.getElementById('search-clear');
  var sortSelect = document.getElementById('sort-select');
  var cardsGrid = document.getElementById('cards-grid');
  var emptyState = document.getElementById('empty-state');
  var emptyReset = document.getElementById('empty-reset');
  var resultsCount = document.getElementById('results-count');
  var statTotalTools = document.getElementById('stat-total-tools');

  function resolveInitialState() {
    var lang = 'en';
    try {
      var params = new URLSearchParams(location.search);
      var qLang = (params.get('lang') || '').toLowerCase();
      if (qLang === 'ru' || qLang === 'en') {
        lang = qLang;
      } else {
        var saved = localStorage.getItem('creator-dir-lang');
        if (saved === 'ru' || saved === 'en') {
          lang = saved;
        }
      }
      var qCat = (params.get('cat') || '').toLowerCase();
      if (CATEGORIES.indexOf(qCat) !== -1) {
        state.category = qCat;
      }
      var qPrice = (params.get('price') || '').toLowerCase();
      if (qPrice === 'all' || qPrice === 'freemium' || qPrice === 'paid') {
        state.pricing = qPrice;
      }
      var qSearch = params.get('q');
      if (qSearch) {
        state.query = qSearch.trim();
      }
    } catch (e) {}
    state.lang = lang;
  }

  function formatResultsCount(shown, total, lang) {
    if (lang === 'ru') {
      return 'Показано сервисов: ' + shown + ' из ' + total;
    }
    return 'Showing ' + shown + ' of ' + total + ' tools';
  }

  function categoryLabel(cat, lang) {
    var t = I18N[lang] || I18N.en;
    return t['cat_' + cat] || cat;
  }

  function pricingTypeLabel(ptype, lang) {
    var t = I18N[lang] || I18N.en;
    return t['ptype_' + ptype] || ptype;
  }

  function matchesPricing(tool, filterVal) {
    if (filterVal === 'all') return true;
    if (filterVal === 'freemium') {
      return tool.pricing_type === 'free' || tool.pricing_type === 'freemium';
    }
    if (filterVal === 'paid') {
      return tool.pricing_type === 'paid';
    }
    return true;
  }

  function matchesQuery(tool, q, lang) {
    if (!q) return true;
    var needle = q.toLowerCase();
    var name = String(tool.name || '').toLowerCase();
    var desc = String(lang === 'ru' ? (tool.desc_ru || tool.desc_en) : tool.desc_en).toLowerCase();
    var badge = String(lang === 'ru' ? (tool.badge_ru || tool.badge_en) : tool.badge_en).toLowerCase();
    var cat = String(categoryLabel(tool.category, lang)).toLowerCase();
    if (name.indexOf(needle) !== -1 || desc.indexOf(needle) !== -1 || badge.indexOf(needle) !== -1 || cat.indexOf(needle) !== -1) {
      return true;
    }
    if (Array.isArray(tool.tags)) {
      for (var i = 0; i < tool.tags.length; i++) {
        if (String(tool.tags[i]).toLowerCase().indexOf(needle) !== -1) {
          return true;
        }
      }
    }
    return false;
  }

  function sortTools(list) {
    return list.slice().sort(function (a, b) {
      // Flagship #1 KoShorts AI Studio is always pinned first among featured items
      var aFlag = a.id === 'koshorts-ai-studio' ? 1 : 0;
      var bFlag = b.id === 'koshorts-ai-studio' ? 1 : 0;
      if (state.sort === 'featured') {
        if (aFlag !== bFlag) return bFlag - aFlag;
        var aFeat = a.featured ? 1 : 0;
        var bFeat = b.featured ? 1 : 0;
        if (aFeat !== bFeat) return bFeat - aFeat;
        return 0;
      }
      if (state.sort === 'newest') {
        if (aFlag !== bFlag) return bFlag - aFlag;
        var cmpDate = String(b.added_at || '').localeCompare(String(a.added_at || ''));
        if (cmpDate !== 0) return cmpDate;
        return String(a.name || '').localeCompare(String(b.name || ''));
      }
      if (state.sort === 'az') {
        return String(a.name || '').localeCompare(String(b.name || ''));
      }
      return 0;
    });
  }

  function updateCategoryCounts() {
    var counts = { all: 0 };
    for (var c = 1; c < CATEGORIES.length; c++) {
      counts[CATEGORIES[c]] = 0;
    }
    for (var i = 0; i < state.tools.length; i++) {
      var tool = state.tools[i];
      if (!matchesPricing(tool, state.pricing)) continue;
      if (!matchesQuery(tool, state.query, state.lang)) continue;
      counts.all += 1;
      if (counts[tool.category] !== undefined) {
        counts[tool.category] += 1;
      }
    }
    document.querySelectorAll('[data-cat-count]').forEach(function (el) {
      var key = el.getAttribute('data-cat-count');
      if (counts[key] !== undefined) {
        el.textContent = String(counts[key]);
      }
    });
  }

  function createToolCard(tool) {
    var lang = state.lang;
    var t = I18N[lang] || I18N.en;
    var isFlagship = tool.id === 'koshorts-ai-studio';

    var card = document.createElement('article');
    card.className = 'tool-card' + (tool.featured ? ' is-featured' : '') + (isFlagship ? ' is-flagship' : '');
    card.setAttribute('data-tool-id', tool.id);

    // Top row: avatar + title/category + badge
    var top = document.createElement('div');
    top.className = 'card-top';

    var ident = document.createElement('div');
    ident.className = 'card-ident';

    var avatar = document.createElement('span');
    avatar.className = 'tool-avatar';
    avatar.setAttribute('aria-hidden', 'true');
    avatar.textContent = String(tool.name || '?').charAt(0).toUpperCase();

    var titleWrap = document.createElement('div');
    titleWrap.className = 'card-title-wrap';

    var h3 = document.createElement('h3');
    h3.className = 'card-title';
    h3.textContent = tool.name;

    var catSpan = document.createElement('span');
    catSpan.className = 'card-cat';
    catSpan.textContent = categoryLabel(tool.category, lang);

    titleWrap.appendChild(h3);
    titleWrap.appendChild(catSpan);
    ident.appendChild(avatar);
    ident.appendChild(titleWrap);
    top.appendChild(ident);

    var badgeText = lang === 'ru' ? tool.badge_ru : tool.badge_en;
    if (badgeText) {
      var badges = document.createElement('div');
      badges.className = 'card-badges';
      var b = document.createElement('span');
      b.className = 'badge ' + (tool.featured ? 'badge-featured' : 'badge-regular');
      b.textContent = badgeText;
      badges.appendChild(b);
      top.appendChild(badges);
    }

    card.appendChild(top);

    // Description
    var desc = document.createElement('p');
    desc.className = 'card-desc';
    desc.textContent = lang === 'ru' ? (tool.desc_ru || tool.desc_en) : tool.desc_en;
    card.appendChild(desc);

    // Pricing box
    var priceBox = document.createElement('div');
    priceBox.className = 'card-pricing';

    var ptype = document.createElement('span');
    var pt = tool.pricing_type || 'freemium';
    ptype.className = 'ptype-pill ptype-' + pt;
    ptype.textContent = pricingTypeLabel(pt, lang);

    var ptext = document.createElement('span');
    ptext.className = 'pricing-text';
    ptext.textContent = lang === 'ru' ? (tool.pricing_ru || tool.pricing_en) : tool.pricing_en;

    priceBox.appendChild(ptype);
    priceBox.appendChild(ptext);
    card.appendChild(priceBox);

    // Tags
    if (Array.isArray(tool.tags) && tool.tags.length > 0) {
      var tagsWrap = document.createElement('div');
      tagsWrap.className = 'card-tags';
      tool.tags.forEach(function (tag) {
        var chip = document.createElement('button');
        chip.type = 'button';
        chip.className = 'tag-chip';
        chip.textContent = '#' + tag;
        chip.addEventListener('click', function () {
          state.query = tag;
          if (searchInput) searchInput.value = tag;
          if (searchClear) searchClear.hidden = false;
          renderDirectory();
        });
        tagsWrap.appendChild(chip);
      });
      card.appendChild(tagsWrap);
    }

    // Actions
    var actions = document.createElement('div');
    actions.className = 'card-actions';

    if (tool.tg) {
      var tgLink = document.createElement('a');
      tgLink.className = 'btn ' + (isFlagship ? 'btn-gold' : 'btn-primary');
      tgLink.href = tool.tg;
      tgLink.target = '_blank';
      tgLink.rel = 'noopener';
      tgLink.textContent = t.btn_telegram;
      actions.appendChild(tgLink);
    }

    if (tool.url && tool.url !== tool.tg) {
      var webLink = document.createElement('a');
      webLink.className = 'btn ' + (tool.tg ? 'btn-ghost' : (tool.featured ? 'btn-gold' : 'btn-primary'));
      webLink.href = tool.url;
      webLink.target = '_blank';
      webLink.rel = 'noopener';
      webLink.textContent = t.btn_website;
      actions.appendChild(webLink);
    }

    card.appendChild(actions);
    return card;
  }

  function renderDirectory() {
    if (!cardsGrid) return;
    updateCategoryCounts();

    var filtered = state.tools.filter(function (tool) {
      if (state.category !== 'all' && tool.category !== state.category) return false;
      if (!matchesPricing(tool, state.pricing)) return false;
      if (!matchesQuery(tool, state.query, state.lang)) return false;
      return true;
    });

    var sorted = sortTools(filtered);
    cardsGrid.textContent = '';

    if (sorted.length === 0) {
      if (emptyState) emptyState.hidden = false;
    } else {
      if (emptyState) emptyState.hidden = true;
      var frag = document.createDocumentFragment();
      for (var i = 0; i < sorted.length; i++) {
        frag.appendChild(createToolCard(sorted[i]));
      }
      cardsGrid.appendChild(frag);
    }

    if (resultsCount) {
      resultsCount.textContent = formatResultsCount(sorted.length, state.tools.length, state.lang);
    }
    if (statTotalTools && state.tools.length > 0) {
      statTotalTools.textContent = state.tools.length + '+';
    }
  }

  function syncUrl() {
    if (typeof history === 'undefined' || typeof history.replaceState !== 'function') return;
    try {
      var params = new URLSearchParams();
      if (state.lang === 'ru') params.set('lang', 'ru');
      if (state.category !== 'all') params.set('cat', state.category);
      if (state.pricing !== 'all') params.set('price', state.pricing);
      if (state.query) params.set('q', state.query);
      var qs = params.toString();
      var next = location.pathname + (qs ? '?' + qs : '') + (location.hash || '');
      history.replaceState(null, '', next);
    } catch (e) {}
  }

  function applyLanguage(lang, persist) {
    state.lang = lang === 'ru' ? 'ru' : 'en';
    var t = I18N[state.lang];
    root.lang = state.lang;

    document.title = t.meta_title;
    if (metaDesc) metaDesc.setAttribute('content', t.meta_desc);
    if (ogTitle) ogTitle.setAttribute('content', t.meta_title);
    if (ogDesc) ogDesc.setAttribute('content', t.meta_desc);
    if (twTitle) twTitle.setAttribute('content', t.meta_title);
    if (twDesc) twDesc.setAttribute('content', t.meta_desc);

    document.querySelectorAll('[data-i18n]').forEach(function (el) {
      var k = el.getAttribute('data-i18n');
      if (t[k] !== undefined) el.textContent = t[k];
    });

    document.querySelectorAll('[data-i18n-aria]').forEach(function (el) {
      var k = el.getAttribute('data-i18n-aria');
      if (t[k] !== undefined) el.setAttribute('aria-label', t[k]);
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach(function (el) {
      var k = el.getAttribute('data-i18n-placeholder');
      if (t[k] !== undefined) el.setAttribute('placeholder', t[k]);
    });

    document.querySelectorAll('.lang-switch button[data-lang]').forEach(function (btn) {
      btn.setAttribute('aria-pressed', btn.getAttribute('data-lang') === state.lang ? 'true' : 'false');
    });

    if (persist) {
      try {
        localStorage.setItem('creator-dir-lang', state.lang);
      } catch (e) {}
      syncUrl();
    }

    renderDirectory();
  }

  function syncFilterButtons() {
    document.querySelectorAll('.cat-btn[data-cat]').forEach(function (btn) {
      btn.setAttribute('aria-pressed', btn.getAttribute('data-cat') === state.category ? 'true' : 'false');
    });
    document.querySelectorAll('.price-btn[data-price]').forEach(function (btn) {
      btn.setAttribute('aria-pressed', btn.getAttribute('data-price') === state.pricing ? 'true' : 'false');
    });
    if (searchInput) searchInput.value = state.query;
    if (searchClear) searchClear.hidden = !state.query;
  }

  function readFallbackSeed() {
    if (Array.isArray(window.CREATOR_TOOLS_SEED) && window.CREATOR_TOOLS_SEED.length > 0) {
      return window.CREATOR_TOOLS_SEED;
    }
    var seedEl = document.getElementById('tools-seed');
    if (!seedEl) return [];
    try {
      var parsed = JSON.parse(seedEl.textContent || '[]');
      return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      return [];
    }
  }

  function loadTools() {
    var seed = readFallbackSeed();
    if (seed.length > 0) {
      state.tools = seed;
      renderDirectory();
    }

    if (typeof fetch === 'function') {
      fetch('./tools.json', { cache: 'no-cache' })
        .then(function (res) {
          if (!res.ok) throw new Error('HTTP ' + res.status);
          return res.json();
        })
        .then(function (data) {
          if (Array.isArray(data) && data.length > 0) {
            state.tools = data;
            renderDirectory();
          }
        })
        .catch(function () {
          // Fallback seed already rendered
        });
    }
  }

  // Initialize
  resolveInitialState();
  syncFilterButtons();
  applyLanguage(state.lang, false);
  loadTools();

  // Event Listeners
  document.querySelectorAll('.lang-switch button[data-lang]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      applyLanguage(btn.getAttribute('data-lang'), true);
    });
  });

  document.querySelectorAll('.cat-btn[data-cat]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      state.category = btn.getAttribute('data-cat') || 'all';
      syncFilterButtons();
      syncUrl();
      renderDirectory();
    });
  });

  document.querySelectorAll('.price-btn[data-price]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      state.pricing = btn.getAttribute('data-price') || 'all';
      syncFilterButtons();
      syncUrl();
      renderDirectory();
    });
  });

  if (searchInput) {
    searchInput.addEventListener('input', function () {
      state.query = searchInput.value.trim();
      if (searchClear) searchClear.hidden = !state.query;
      syncUrl();
      renderDirectory();
    });
  }

  if (searchClear) {
    searchClear.addEventListener('click', function () {
      state.query = '';
      if (searchInput) {
        searchInput.value = '';
        searchInput.focus();
      }
      searchClear.hidden = true;
      syncUrl();
      renderDirectory();
    });
  }

  if (sortSelect) {
    sortSelect.addEventListener('change', function () {
      state.sort = sortSelect.value || 'featured';
      renderDirectory();
    });
  }

  if (emptyReset) {
    emptyReset.addEventListener('click', function () {
      state.category = 'all';
      state.pricing = 'all';
      state.query = '';
      state.sort = 'featured';
      if (sortSelect) sortSelect.value = 'featured';
      syncFilterButtons();
      syncUrl();
      renderDirectory();
    });
  }

  // Keyboard shortcut "/" to focus search input
  document.addEventListener('keydown', function (e) {
    if (e.key === '/' && searchInput && document.activeElement !== searchInput) {
      var tag = document.activeElement && document.activeElement.tagName;
      if (tag !== 'INPUT' && tag !== 'TEXTAREA' && tag !== 'SELECT') {
        e.preventDefault();
        searchInput.focus();
      }
    }
  });

  var yearEl = document.getElementById('year');
  if (yearEl) {
    yearEl.textContent = String(new Date().getFullYear());
  }
})();
