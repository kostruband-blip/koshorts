#!/usr/bin/env python3
"""
Autonomous CreatorDirectory expansion script.

Reads tools.json, deduplicates existing domains/Telegram handles/names,
queries the Gemini API using multi-key + multi-model rotation with 429/503
retry handling, verifies live HTTP reachability (< 400) for every candidate URL,
validates the strict JSON schema, updates tools.json + assets/seed.js + sitemap.xml,
and sends a summary notification to Telegram.
"""

from __future__ import annotations

import argparse
import datetime as dt
import ipaddress
import json
import os
import re
import socket
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Callable

ROOT = Path(__file__).resolve().parent
TOOLS_PATH = ROOT / "tools.json"
SEED_JS_PATH = ROOT / "assets" / "seed.js"
SITEMAP_PATH = ROOT / "sitemap.xml"

VALID_CATEGORIES = ("shorts", "captions", "dubbing", "thumbnails", "analytics", "telegram")
VALID_PRICING_TYPES = ("free", "freemium", "paid")

# Primary requested model carousel + resilient fallback
GEMINI_MODELS = (
    "gemini-flash-latest",
    "gemini-3.8-flash",
    "gemini-3.7-flash",
    "gemini-pro-latest",
    "gemini-2.5-flash",
)

SLUG_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
CYRILLIC_RE = re.compile(r"[А-Яа-яЁёІіЇїЄєҐґ]")

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/131.0.0.0 Safari/537.36 CreatorDirectoryBot/1.0"
)


def normalize_name(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (name or "").lower())


def extract_identity(url: str) -> str:
    """
    Return a canonical deduplication identity for a URL:
    - For Telegram links (t.me / telegram.me), return 't.me/<handle>' so distinct
      Telegram bots do not collide on the shared t.me domain.
    - For standard websites, return the lowercase hostname without 'www.'.
    """
    try:
        parsed = urllib.parse.urlparse(url.strip())
    except Exception:
        return ""
    host = (parsed.hostname or "").lower()
    if host.startswith("www."):
        host = host[4:]
    if host in ("t.me", "telegram.me"):
        parts = [p for p in parsed.path.split("/") if p]
        if parts:
            return f"t.me/{parts[0].lower()}"
    return host


def collect_existing_fingerprints(tools: list[dict[str, Any]]) -> tuple[set[str], set[str], set[str]]:
    ids: set[str] = set()
    names: set[str] = set()
    identities: set[str] = set()
    for item in tools:
        if item.get("id"):
            ids.add(str(item["id"]).strip().lower())
        if item.get("name"):
            names.add(normalize_name(str(item["name"])))
        for field in ("url", "tg"):
            val = str(item.get(field) or "").strip()
            if val:
                ident = extract_identity(val)
                if ident:
                    identities.add(ident)
    return ids, names, identities


def is_public_host(hostname: str) -> bool:
    if not hostname:
        return False
    try:
        infos = socket.getaddrinfo(hostname, None)
    except OSError:
        return False
    for info in infos:
        ip_str = info[4][0]
        try:
            ip_obj = ipaddress.ip_address(ip_str)
            if (
                ip_obj.is_private
                or ip_obj.is_loopback
                or ip_obj.is_link_local
                or ip_obj.is_multicast
                or ip_obj.is_reserved
            ):
                return False
        except ValueError:
            return False
    return True


def check_url_reachable(url: str, timeout: float = 10.0) -> bool:
    """Verify URL uses HTTPS, resolves to a public IP, and returns HTTP status < 400."""
    try:
        parsed = urllib.parse.urlparse(url)
    except Exception:
        return False
    if parsed.scheme != "https" or not parsed.hostname:
        return False
    if not is_public_host(parsed.hostname):
        return False

    for method in ("HEAD", "GET"):
        headers = {"User-Agent": USER_AGENT, "Accept": "text/html,application/xhtml+xml,*/*;q=0.8"}
        if method == "GET":
            headers["Range"] = "bytes=0-2048"
        req = urllib.request.Request(url, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                status = getattr(resp, "status", resp.getcode())
                if status is not None and int(status) < 400:
                    return True
        except urllib.error.HTTPError as exc:
            # Many Cloudflare-fronted SaaS sites reject HEAD with 403/405; retry with GET
            if method == "HEAD" and exc.code in (403, 405):
                continue
            return False
        except Exception:
            if method == "HEAD":
                continue
            return False
    return False


def validate_and_clean_tool(
    raw: dict[str, Any],
    today_str: str,
    target_category: str = "any",
) -> dict[str, Any] | None:
    """Validate strict CreatorDirectory tool schema and sanitize fields."""
    if not isinstance(raw, dict):
        return None

    slug = re.sub(r"[^a-z0-9-]+", "-", str(raw.get("id") or "").strip().lower()).strip("-")
    name = str(raw.get("name") or "").strip()
    category = str(raw.get("category") or "").strip().lower()
    badge_en = str(raw.get("badge_en") or "Verified AI").strip()
    badge_ru = str(raw.get("badge_ru") or "Проверено").strip()
    pricing_type = str(raw.get("pricing_type") or "").strip().lower()
    pricing_en = str(raw.get("pricing_en") or "").strip()
    pricing_ru = str(raw.get("pricing_ru") or "").strip()
    desc_en = str(raw.get("desc_en") or "").strip()
    desc_ru = str(raw.get("desc_ru") or "").strip()
    url = str(raw.get("url") or "").strip()
    tg = str(raw.get("tg") or "").strip()
    added_at = str(raw.get("added_at") or today_str).strip()

    if not SLUG_RE.match(slug) or not name:
        return None
    if category not in VALID_CATEGORIES:
        return None
    if target_category != "any" and category != target_category:
        return None
    if pricing_type not in VALID_PRICING_TYPES:
        return None
    if not (pricing_en and pricing_ru and desc_en and desc_ru):
        return None
    # Enforce zero Cyrillic in English-facing fields
    if any(CYRILLIC_RE.search(field) for field in (name, badge_en, pricing_en, desc_en)):
        return None
    if not CYRILLIC_RE.search(desc_ru):
        return None
    if not url.startswith("https://"):
        return None
    if tg and not tg.startswith("https://t.me/"):
        tg = ""

    raw_tags = raw.get("tags")
    if not isinstance(raw_tags, list):
        return None
    tags: list[str] = []
    for t in raw_tags:
        clean_t = str(t).strip().lower().lstrip("#")
        if clean_t and not CYRILLIC_RE.search(clean_t) and clean_t not in tags:
            tags.append(clean_t)
    if len(tags) < 3:
        return None
    tags = tags[:5]

    if not DATE_RE.match(added_at):
        added_at = today_str

    return {
        "id": slug,
        "name": name,
        "category": category,
        "featured": False,  # Auto-discovered items never override paid/flagship Featured spots
        "badge_en": badge_en,
        "badge_ru": badge_ru,
        "pricing_type": pricing_type,
        "pricing_en": pricing_en,
        "pricing_ru": pricing_ru,
        "desc_en": desc_en,
        "desc_ru": desc_ru,
        "tags": tags,
        "url": url,
        "tg": tg,
        "added_at": added_at,
    }


def get_api_keys() -> list[str]:
    keys: list[str] = []
    for env_name in ("GEMINI_API_KEY", "GEMINI_API_KEY_2", "GEMINI_API_KEY_3"):
        val = (os.environ.get(env_name) or "").strip()
        if val and val not in keys:
            keys.append(val)
    return keys


def build_prompt(
    count: int,
    target_category: str,
    existing_names: list[str],
    existing_identities: list[str],
    today_str: str,
) -> str:
    ask_count = max(count + 3, count * 2)
    cat_instruction = (
        f'Strictly pick tools ONLY in the "{target_category}" category.'
        if target_category != "any"
        else f"Pick tools distributed across these categories: {', '.join(VALID_CATEGORIES)}."
    )
    return f"""You are a senior AI directory curator for CreatorDirectory (AI tools & Telegram bots for YouTube, TikTok, Reels, and Telegram channel creators).

Return a JSON array of {ask_count} REAL, well-known, currently active AI tools or Telegram bots for creators that are NOT already in our catalog.
{cat_instruction}

Already listed tool names (DO NOT repeat any of these):
{json.dumps(sorted(existing_names)[:200], ensure_ascii=False)}

Already listed domains/handles (DO NOT repeat any of these):
{json.dumps(sorted(existing_identities)[:200], ensure_ascii=False)}

Every object in the returned JSON array MUST strictly match this schema:
{{
  "id": "unique-latin-slug",
  "name": "Official Tool Name (Latin characters only)",
  "category": "one of: shorts | captions | dubbing | thumbnails | analytics | telegram",
  "featured": false,
  "badge_en": "2-3 word English badge (zero Cyrillic)",
  "badge_ru": "2-3 word Russian badge",
  "pricing_type": "one of: free | freemium | paid",
  "pricing_en": "Concise English pricing summary (zero Cyrillic)",
  "pricing_ru": "Краткая строка цены на русском",
  "desc_en": "2-3 crisp English sentences describing what creator pain it solves and who it is for (zero Cyrillic).",
  "desc_ru": "2-3 чётких предложения на русском языке: какую боль решает и для кого подходит.",
  "tags": ["3 to 5", "lowercase english", "search keywords"],
  "url": "https://official-working-domain.com",
  "tg": "https://t.me/official_bot_if_exists_else_empty_string",
  "added_at": "{today_str}"
}}

CRITICAL RULES:
1. Never invent or guess URLs. Only include real, established products with working HTTPS homepages.
2. Zero Cyrillic characters in name, badge_en, pricing_en, desc_en, or tags.
3. Return ONLY a raw JSON array `[...]` with no markdown code fences.
"""


def parse_json_candidates(text: str) -> list[dict[str, Any]]:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    data = json.loads(cleaned)
    if isinstance(data, dict) and isinstance(data.get("tools"), list):
        return data["tools"]
    if isinstance(data, list):
        return data
    raise ValueError("Gemini response is not a JSON list")


def query_gemini_with_rotation(
    prompt: str,
    api_keys: list[str],
    models: tuple[str, ...] = GEMINI_MODELS,
) -> list[dict[str, Any]]:
    """Rotate across models and API keys, gracefully bypassing 429/503/404 errors."""
    if not api_keys:
        raise RuntimeError("No GEMINI_API_KEY configured in environment variables.")

    last_error: Exception | None = None
    for model in models:
        for key_idx, api_key in enumerate(api_keys, start=1):
            endpoint = (
                f"https://generativelanguage.googleapis.com/v1beta/models/"
                f"{urllib.parse.quote(model)}:generateContent?key={urllib.parse.quote(api_key)}"
            )
            payload = {
                "contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {
                    "temperature": 0.35,
                    "responseMimeType": "application/json",
                },
            }
            req = urllib.request.Request(
                endpoint,
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            try:
                with urllib.request.urlopen(req, timeout=45) as resp:
                    body = json.loads(resp.read().decode("utf-8"))
                parts = body["candidates"][0]["content"]["parts"]
                raw_text = "".join(p.get("text", "") for p in parts)
                candidates = parse_json_candidates(raw_text)
                print(f"[OK] Received {len(candidates)} candidates from {model} (key #{key_idx})")
                return candidates
            except urllib.error.HTTPError as exc:
                last_error = exc
                print(f"[WARN] {model} (key #{key_idx}) returned HTTP {exc.code}; rotating...")
                if exc.code in (429, 503):
                    time.sleep(1.5)
                continue
            except Exception as exc:
                last_error = exc
                print(f"[WARN] {model} (key #{key_idx}) failed ({exc}); rotating...")
                continue

    raise RuntimeError(f"All Gemini models and API keys exhausted. Last error: {last_error}")


def send_telegram_report(added_tools: list[dict[str, Any]]) -> None:
    token = (os.environ.get("TELEGRAM_BOT_TOKEN") or "").strip()
    chat_id = (os.environ.get("TELEGRAM_CHAT_ID") or "").strip()
    if not token or not chat_id or not added_tools:
        return

    lines = [f"✅ CreatorDirectory auto-updated (+{len(added_tools)} new tools):"]
    for idx, item in enumerate(added_tools, start=1):
        lines.append(f"{idx}. {item['name']} [{item['category']}] — {item['url']}")
    text = "\n".join(lines)

    endpoint = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = json.dumps(
        {"chat_id": chat_id, "text": text, "disable_web_page_preview": True}
    ).encode("utf-8")
    req = urllib.request.Request(
        endpoint,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            print(f"[OK] Sent Telegram notification (HTTP {resp.getcode()})")
    except Exception as exc:
        print(f"[WARN] Failed to send Telegram notification: {exc}")


def write_outputs(tools: list[dict[str, Any]], today_str: str) -> None:
    TOOLS_PATH.write_text(json.dumps(tools, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    SEED_JS_PATH.parent.mkdir(parents=True, exist_ok=True)
    SEED_JS_PATH.write_text(
        "window.CREATOR_TOOLS_SEED = " + json.dumps(tools, ensure_ascii=False, indent=2) + ";\n",
        encoding="utf-8",
    )

    if SITEMAP_PATH.exists():
        xml = SITEMAP_PATH.read_text(encoding="utf-8")
        updated_xml = re.sub(r"<lastmod>[^<]+</lastmod>", f"<lastmod>{today_str}</lastmod>", xml)
        SITEMAP_PATH.write_text(updated_xml, encoding="utf-8")


def expand_directory(
    count: int = 3,
    target_category: str = "any",
    dry_run: bool = False,
    candidates_provider: Callable[[str], list[dict[str, Any]]] | None = None,
    url_checker: Callable[[str], bool] = check_url_reachable,
) -> list[dict[str, Any]]:
    if count <= 0:
        return []
    target_category = target_category.strip().lower() or "any"
    if target_category != "any" and target_category not in VALID_CATEGORIES:
        raise ValueError(f"Invalid category '{target_category}'. Expected one of: any, {', '.join(VALID_CATEGORIES)}")

    tools: list[dict[str, Any]] = json.loads(TOOLS_PATH.read_text(encoding="utf-8"))
    seen_ids, seen_names, seen_identities = collect_existing_fingerprints(tools)
    today_str = dt.date.today().isoformat()

    prompt = build_prompt(
        count=count,
        target_category=target_category,
        existing_names=[str(t.get("name", "")) for t in tools],
        existing_identities=list(seen_identities),
        today_str=today_str,
    )

    if candidates_provider is not None:
        raw_candidates = candidates_provider(prompt)
    else:
        raw_candidates = query_gemini_with_rotation(prompt, get_api_keys())

    added: list[dict[str, Any]] = []
    for raw in raw_candidates:
        if len(added) >= count:
            break
        cleaned = validate_and_clean_tool(raw, today_str=today_str, target_category=target_category)
        if not cleaned:
            continue

        norm_n = normalize_name(cleaned["name"])
        ident = extract_identity(cleaned["url"])
        tg_ident = extract_identity(cleaned["tg"]) if cleaned["tg"] else ""

        if (
            cleaned["id"] in seen_ids
            or norm_n in seen_names
            or not ident
            or ident in seen_identities
            or (tg_ident and tg_ident in seen_identities)
        ):
            print(f"[SKIP] Duplicate skipped: {cleaned['name']} ({cleaned['url']})")
            continue

        if not url_checker(cleaned["url"]):
            print(f"[SKIP] Unreachable URL skipped: {cleaned['name']} ({cleaned['url']})")
            continue

        if cleaned["tg"] and not url_checker(cleaned["tg"]):
            cleaned["tg"] = ""

        seen_ids.add(cleaned["id"])
        seen_names.add(norm_n)
        seen_identities.add(ident)
        if tg_ident:
            seen_identities.add(tg_ident)

        tools.append(cleaned)
        added.append(cleaned)
        print(f"[ADD] {cleaned['name']} ({cleaned['category']}) -> {cleaned['url']}")

    if added and not dry_run:
        write_outputs(tools, today_str)
        send_telegram_report(added)

    return added


def main() -> int:
    parser = argparse.ArgumentParser(description="Auto-expand CreatorDirectory with verified AI tools.")
    parser.add_argument(
        "--count",
        type=int,
        default=int(os.environ.get("INPUT_COUNT") or "3"),
        help="Number of new verified tools to add (default: 3)",
    )
    parser.add_argument(
        "--category",
        type=str,
        default=os.environ.get("INPUT_TARGET_CATEGORY") or "any",
        help="Target category (shorts, captions, dubbing, thumbnails, analytics, telegram, or any)",
    )
    parser.add_argument("--dry-run", action="store_true", help="Validate without writing files")
    args = parser.parse_args()

    added = expand_directory(count=args.count, target_category=args.category, dry_run=args.dry_run)
    print(f"Done. Added {len(added)} new tool(s).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
